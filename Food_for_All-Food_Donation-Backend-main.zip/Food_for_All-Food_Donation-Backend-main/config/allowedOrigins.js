const allowedOrigins = [
    'http://localhost:8070',
    'http://localhost:3500',
    'http://localhost:3000',
    'http://localhost:8070/'
];

module.exports = allowedOrigins;