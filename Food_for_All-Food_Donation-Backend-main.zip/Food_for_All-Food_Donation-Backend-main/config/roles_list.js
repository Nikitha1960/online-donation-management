const ROLES_LIST = {
    "organizatioin": 5150,
    "user": 1984,
    "admin": 2001
}

module.exports = ROLES_LIST